package trivera.datetime.client.swing;

import trivera.datetime.appointment.Appointment;

public interface AppointmentScheduler {
	void addAppointment(Appointment appointment);
}
